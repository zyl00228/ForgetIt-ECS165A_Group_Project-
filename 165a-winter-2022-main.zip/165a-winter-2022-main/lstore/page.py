from time import time
import math

class PhysicalPage:

    def __init__(self):
        self.num_records = 0
        self.data = bytearray(4096)

    def has_capacity(self):
        if self.num_records > 1024:
            return False
        return True

    def write(self, value):
        if self.has_capacity():
            start = self.num_records * 4
            end = (self.num_records + 1) * 4
            self.data[start:end] = value.to_bytes(4, 'big')
            self.num_records += 1
            return True
        else:
            return False

    def read(self, location):
        pass

    def update(self, value, location):
        pass

class Page:

    def __init__(self, num_columns):
        self.num_col = num_columns
        self.metaColumns = []
        for i in range(4):
            self.metaColumns.append(PhysicalPage())
        self.dataColumns = []
        for cols in range(num_columns):
            self.dataColumns.append(PhysicalPage())

    def insert_base_page(self, RID, record_data):
        # self.metaColumns[0].write(0)  # Indirection column
        # self.metaColumns[1].write(RID)  # RID column
        # self.metaColumns[2].write(time())  # Timestamp column
        # self.metaColumns[3].write('0' * self.num_col)  # Schema encoding column
        for i in range(self.num_col):
            self.dataColumns[i].write(record_data[i])

    def insert_tail_page(self, RID, record):
        pass

    def get_record(self, offset):
        pass

    def append_record(self, RID, page_offset):
        pass

    def is_full(self):
        pass

    def init_record_metadata(self, base_RID):
        pass

    def invalidate_record(self, page_offset):
        pass


class PageRange:

    def __init__(self, num_columns):
        self.num_columns = num_columns
        self.base_pages = [Page(num_columns)]
        self.tail_pages = []
        self.tail_rid = -1

    def insert_base(self, RID, record_data):
        page_index = self.calc_page_index(RID)
        if len(self.base_pages) <= page_index:
            self.base_pages.append(Page(self.num_columns))
        self.base_pages[page_index].insert_base_page(RID, record_data)

    def insert_tail(self, RID, full_record):
        pass

    def update(self, base_RID, updated_record):
        pass

    def get_prev_tail(self, base_indirection):
        pass

    def select(self, key, base_RID):
        pass

    def delete(self, key, base_RID):
        pass

    def invalidate_tails(self, indirection, base_indirection):
        pass

    def calc_page_index(self, RID):
        return math.floor(RID / 1024)

    def calc_page_offset(self, RID):
        pass

    def add_page(self, record):
        pass

    def merge_record(self, old_record, updated_record):
        pass

