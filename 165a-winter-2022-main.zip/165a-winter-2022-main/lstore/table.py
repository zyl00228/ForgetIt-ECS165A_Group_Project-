import os
import sys
sys.path.append(os.path.abspath(os.path.join(os.path.dirname("__file__"), '..')))
from lstore.index import Index
from lstore.page import *
from time import time
import math

INDIRECTION_COLUMN = 0
RID_COLUMN = 1
TIMESTAMP_COLUMN = 2
SCHEMA_ENCODING_COLUMN = 3


class Record:

    def __init__(self, rid, key, columns):
        self.rid = rid
        self.key = key
        self.columns = columns

class Table:

    """
    :param name: string         #Table name
    :param num_columns: int     #Number of Columns: all columns are integer
    :param key: int             #Index of table key in columns
    """
    def __init__(self, name, num_columns, key):
        self.name = name
        self.key = key
        self.num_columns = num_columns
        self.page_directory = [PageRange(num_columns)]
        self.keyToRID = {}
        self.baseRID = -1
        self.index = Index(self)

    def insert(self, record_data):
        self.baseRID += 1
        page_range_index = self.get_page_range(self.baseRID)
        if len(self.page_directory) <= page_range_index:
            self.page_directory.append(PageRange(self.num_columns))
        self.page_directory[0].insert_base(self.baseRID, record_data)

    def update(self, key, record):
        pass

    def select(self, key, column, query_columns):
        pass

    def delete(self, key):
        pass

    def sum(self, start, end, aggregate_col_index):
        pass

    def get_page_range(self, base_RID):
        return math.floor(base_RID / 4096)

    def __merge(self):
        print("merge is happening")
        pass
